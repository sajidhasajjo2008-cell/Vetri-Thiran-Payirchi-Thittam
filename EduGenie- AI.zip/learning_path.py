"""
EduGenie - Learning Path Module

Generates a structured learning path for a student based on
the requested topic and learner level.
"""

from __future__ import annotations

import json
import re
from typing import Any, Dict, List

from ai_client import GeminiClientError, generate_ai_json


# =========================================================
# Constants
# =========================================================

DEFAULT_LEVEL = "beginner"

ALLOWED_LEVELS = {
    "beginner",
    "intermediate",
    "advanced",
}


# =========================================================
# Prompt
# =========================================================

def build_learning_path_prompt(
    topic: str,
    level: str,
) -> str:

    return f"""
You are EduGenie, an AI-powered learning assistant.

Create a structured learning path for the following topic:

Topic:
{topic}

Learner level:
{level}

Create a progression from the learner's current level toward
more advanced understanding.

Requirements:

1. Provide 5 to 7 learning steps.
2. Start with the appropriate foundation.
3. Progress from simple concepts to more advanced concepts.
4. Give every step a clear topic.
5. Give every step a short description.
6. Give every step a difficulty.
7. Give an estimated study time.
8. Provide 3 to 5 useful learning resources.
9. Resources may include documentation, tutorials,
   books, courses, or educational websites.
10. Do not invent specific URLs if you are not confident
    that they are valid.
11. Keep the content educational and practical.
12. Return ONLY valid JSON.
13. Do not use Markdown.
14. Do not put the JSON inside code fences.

Return exactly this structure:

{{
  "learning_path": [
    {{
      "step": 1,
      "topic": "Foundation",
      "description": "Description",
      "difficulty": "Beginner",
      "estimated_time": "2 hours"
    }}
  ],
  "resources": [
    {{
      "title": "Resource title",
      "description": "Resource description",
      "resource_type": "Documentation",
      "url": null
    }}
  ]
}}
""".strip()


# =========================================================
# Clean JSON
# =========================================================

def clean_json_response(response_text: str) -> str:
    """
    Remove Markdown code fences if Gemini adds them.
    """

    if not response_text:
        raise ValueError(
            "Gemini returned an empty learning path."
        )

    cleaned = response_text.strip()

    cleaned = re.sub(
        r"^```json\s*",
        "",
        cleaned,
        flags=re.IGNORECASE,
    )

    cleaned = re.sub(
        r"^```\s*",
        "",
        cleaned,
    )

    cleaned = re.sub(
        r"\s*```$",
        "",
        cleaned,
    )

    return cleaned.strip()


# =========================================================
# Parse JSON
# =========================================================

def parse_learning_path_json(
    response_text: str,
) -> Dict[str, Any]:

    cleaned = clean_json_response(
        response_text
    )

    try:

        data = json.loads(cleaned)

    except json.JSONDecodeError as exc:

        raise ValueError(
            f"Invalid learning-path JSON: {exc}"
        ) from exc

    if not isinstance(data, dict):
        raise ValueError(
            "Learning path must be a JSON object."
        )

    if "learning_path" not in data:
        raise ValueError(
            "Missing 'learning_path' field."
        )

    if "resources" not in data:
        raise ValueError(
            "Missing 'resources' field."
        )

    return data


# =========================================================
# Validate learning steps
# =========================================================

def validate_learning_steps(
    steps: Any,
) -> List[Dict[str, Any]]:

    if not isinstance(steps, list):
        raise ValueError(
            "learning_path must be a list."
        )

    if len(steps) < 5 or len(steps) > 7:
        raise ValueError(
            "Learning path must contain between 5 and 7 steps."
        )

    validated_steps = []

    for index, item in enumerate(steps, start=1):

        if not isinstance(item, dict):
            raise ValueError(
                "Each learning step must be an object."
            )

        required_fields = [
            "step",
            "topic",
            "description",
            "difficulty",
            "estimated_time",
        ]

        for field in required_fields:

            if field not in item:
                raise ValueError(
                    f"Learning step is missing '{field}'."
                )

        topic = str(
            item["topic"]
        ).strip()

        description = str(
            item["description"]
        ).strip()

        difficulty = str(
            item["difficulty"]
        ).strip()

        estimated_time = str(
            item["estimated_time"]
        ).strip()

        if not topic:
            raise ValueError(
                "Learning step topic cannot be empty."
            )

        if not description:
            raise ValueError(
                "Learning step description cannot be empty."
            )

        if not difficulty:
            raise ValueError(
                "Learning step difficulty cannot be empty."
            )

        if not estimated_time:
            raise ValueError(
                "Learning step estimated_time cannot be empty."
            )

        validated_steps.append(
            {
                "step": index,
                "topic": topic,
                "description": description,
                "difficulty": difficulty,
                "estimated_time": estimated_time,
            }
        )

    return validated_steps


# =========================================================
# Validate resources
# =========================================================

def validate_resources(
    resources: Any,
) -> List[Dict[str, Any]]:

    if not isinstance(resources, list):
        raise ValueError(
            "resources must be a list."
        )

    if len(resources) < 3 or len(resources) > 5:
        raise ValueError(
            "Learning path must contain between 3 and 5 resources."
        )

    validated_resources = []

    for resource in resources:

        if not isinstance(resource, dict):
            raise ValueError(
                "Each resource must be an object."
            )

        required_fields = [
            "title",
            "description",
            "resource_type",
        ]

        for field in required_fields:

            if field not in resource:
                raise ValueError(
                    f"Resource is missing '{field}'."
                )

        title = str(
            resource["title"]
        ).strip()

        description = str(
            resource["description"]
        ).strip()

        resource_type = str(
            resource["resource_type"]
        ).strip()

        url = resource.get("url")

        if url is not None:
            url = str(url).strip()

            if not url:
                url = None

        if not title:
            raise ValueError(
                "Resource title cannot be empty."
            )

        if not description:
            raise ValueError(
                "Resource description cannot be empty."
            )

        if not resource_type:
            raise ValueError(
                "Resource type cannot be empty."
            )

        validated_resources.append(
            {
                "title": title,
                "description": description,
                "resource_type": resource_type,
                "url": url,
            }
        )

    return validated_resources


# =========================================================
# Generate learning path
# =========================================================

def generate_learning_path(
    topic: str,
    level: str = DEFAULT_LEVEL,
) -> Dict[str, Any]:

    if not topic or not topic.strip():
        raise ValueError(
            "Topic cannot be empty."
        )

    cleaned_topic = topic.strip()

    cleaned_level = (
        level.strip().lower()
        if level
        else DEFAULT_LEVEL
    )

    if cleaned_level not in ALLOWED_LEVELS:
        raise ValueError(
            "Level must be beginner, intermediate, or advanced."
        )

    prompt = build_learning_path_prompt(
        topic=cleaned_topic,
        level=cleaned_level,
    )

    response = generate_ai_json(
        prompt=prompt,
        temperature=0.4,
        max_output_tokens=3000,
    )

    data = parse_learning_path_json(
        response
    )

    learning_steps = validate_learning_steps(
        data["learning_path"]
    )

    resources = validate_resources(
        data["resources"]
    )

    return {
        "topic": cleaned_topic,
        "level": cleaned_level,
        "learning_path": learning_steps,
        "resources": resources,
    }


# =========================================================
# Safe helper
# =========================================================

def generate_learning_path_safe(
    topic: str,
    level: str = DEFAULT_LEVEL,
) -> dict:

    try:

        result = generate_learning_path(
            topic=topic,
            level=level,
        )

        return {
            "success": True,
            **result,
            "error": None,
        }

    except ValueError as exc:

        return {
            "success": False,
            "topic": topic,
            "level": level,
            "learning_path": [],
            "resources": [],
            "error": str(exc),
        }

    except GeminiClientError as exc:

        return {
            "success": False,
            "topic": topic,
            "level": level,
            "learning_path": [],
            "resources": [],
            "error": str(exc),
        }

    except Exception as exc:

        return {
            "success": False,
            "topic": topic,
            "level": level,
            "learning_path": [],
            "resources": [],
            "error": f"Unexpected error: {exc}",
        }