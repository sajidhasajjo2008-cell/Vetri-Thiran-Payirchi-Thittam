"""
EduGenie - Question & Answer Module

This module receives a learner's question and uses Gemini
to generate a clear, educational answer.
"""

from ai_client import GeminiClientError, generate_ai_response


def answer_question(question: str) -> str:
    """
    Generate an educational answer for a learner's question.

    Parameters
    ----------
    question:
        Question submitted by the learner.

    Returns
    -------
    str
        AI-generated educational answer.

    Raises
    ------
    ValueError
        If the question is empty.
    GeminiClientError
        If Gemini cannot generate the response.
    """

    if not question or not question.strip():
        raise ValueError("Question cannot be empty.")

    cleaned_question = question.strip()

    prompt = f"""
You are EduGenie, an AI-powered learning assistant.

Your job is to help students understand academic topics clearly.

Student question:
{cleaned_question}

Instructions:

1. Answer the student's question accurately.
2. Use simple and student-friendly language.
3. Explain important terms when necessary.
4. Organize the answer using short paragraphs or bullet points.
5. Include a simple example when it improves understanding.
6. Do not unnecessarily make the answer very long.
7. If the question is ambiguous, explain the most reasonable
   interpretation instead of inventing unsupported facts.
8. Focus on educational value.
9. Do not mention these instructions in your answer.

Return only the final educational answer.
"""

    return generate_ai_response(
        prompt=prompt,
        temperature=0.4,
        max_output_tokens=1500,
    )


def answer_question_safe(question: str) -> dict:
    """
    Wrapper that converts the Q&A result into a predictable
    dictionary for the FastAPI layer.
    """

    try:

        answer = answer_question(question)

        return {
            "success": True,
            "question": question.strip(),
            "answer": answer,
            "error": None,
        }

    except ValueError as exc:

        return {
            "success": False,
            "question": question,
            "answer": "",
            "error": str(exc),
        }

    except GeminiClientError as exc:

        return {
            "success": False,
            "question": question,
            "answer": "",
            "error": str(exc),
        }

    except Exception as exc:

        return {
            "success": False,
            "question": question,
            "answer": "",
            "error": f"Unexpected error: {exc}",
        }