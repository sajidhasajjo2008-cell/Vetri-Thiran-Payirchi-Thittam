"""
EduGenie - FastAPI Backend

Main application file.

This file:
    1. Creates the FastAPI application.
    2. Serves the frontend.
    3. Provides all EduGenie API endpoints.
    4. Connects the API endpoints to the AI modules.
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from config import (
    APP_NAME,
    APP_VERSION,
    DEBUG,
    GEMINI_API_KEY,
    HOST,
    PORT,
)

from models import (
    ExplanationRequest,
    ExplanationResponse,
    HealthResponse,
    LearningPathRequest,
    LearningPathResponse,
    QARequest,
    QAResponse,
    QuizRequest,
    QuizResponse,
    SummaryRequest,
    SummaryResponse,
)

from qna import answer_question
from explanation_module import explain_concept
from quiz_module import generate_quiz
from summary_module import summarize_text
from learning_path import generate_learning_path

from ai_client import GeminiClientError


# =========================================================
# Project directories
# =========================================================

BASE_DIR = Path(__file__).resolve().parent

TEMPLATES_DIR = BASE_DIR / "templates"

STATIC_DIR = BASE_DIR / "static"

INDEX_FILE = TEMPLATES_DIR / "index.html"


# =========================================================
# FastAPI application
# =========================================================

app = FastAPI(
    title=APP_NAME,
    version=APP_VERSION,
    description=(
        "EduGenie is a Google Gemini powered learning "
        "assistant providing Q&A, concept explanation, "
        "quiz generation, summarization and learning paths."
    ),
    debug=DEBUG,
)


# =========================================================
# CORS
# =========================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:8000",
        "http://localhost:8000",
        "http://127.0.0.1:5500",
        "http://localhost:5500",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =========================================================
# Static files
# =========================================================

if STATIC_DIR.exists():

    app.mount(
        "/static",
        StaticFiles(directory=str(STATIC_DIR)),
        name="static",
    )


# =========================================================
# Home page
# =========================================================

@app.get(
    "/",
    include_in_schema=False,
)
async def home():

    if not INDEX_FILE.exists():

        return {
            "application": APP_NAME,
            "version": APP_VERSION,
            "message": (
                "EduGenie backend is running. "
                "Frontend index.html has not been created yet."
            ),
        }

    return FileResponse(
        str(INDEX_FILE)
    )


# =========================================================
# Health check
# =========================================================

@app.get(
    "/health",
    response_model=HealthResponse,
)
async def health_check():

    return HealthResponse(
        status="healthy",
        application=APP_NAME,
        version=APP_VERSION,
        gemini_configured=bool(GEMINI_API_KEY),
    )


# =========================================================
# Q&A endpoint
# =========================================================

@app.post(
    "/qa",
    response_model=QAResponse,
)
async def question_answer(
    request: QARequest,
):

    try:

        answer = answer_question(
            request.question
        )

        return QAResponse(
            question=request.question,
            answer=answer,
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        )

    except GeminiClientError as exc:

        raise HTTPException(
            status_code=503,
            detail=str(exc),
        )

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "An unexpected error occurred "
                f"while answering the question: {exc}"
            ),
        )


# =========================================================
# Concept explanation endpoint
# =========================================================

@app.post(
    "/explain",
    response_model=ExplanationResponse,
)
async def explain(
    request: ExplanationRequest,
):

    try:

        explanation = explain_concept(
            topic=request.topic,
            level=request.level,
        )

        return ExplanationResponse(
            topic=request.topic,
            level=request.level,
            explanation=explanation,
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        )

    except RuntimeError as exc:

        raise HTTPException(
            status_code=503,
            detail=str(exc),
        )

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "An unexpected error occurred "
                f"while explaining the topic: {exc}"
            ),
        )


# =========================================================
# Quiz endpoint
# =========================================================

@app.post(
    "/quiz",
    response_model=QuizResponse,
)
async def quiz(
    request: QuizRequest,
):

    try:

        questions = generate_quiz(
            passage=request.passage,
            number_of_questions=request.number_of_questions,
        )

        return QuizResponse(
            questions=questions
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        )

    except GeminiClientError as exc:

        raise HTTPException(
            status_code=503,
            detail=str(exc),
        )

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "An unexpected error occurred "
                f"while generating the quiz: {exc}"
            ),
        )


# =========================================================
# Summarization endpoint
# =========================================================

@app.post(
    "/summarize",
    response_model=SummaryResponse,
)
async def summarize(
    request: SummaryRequest,
):

    try:

        summary = summarize_text(
            text=request.text,
            max_words=request.max_words,
        )

        return SummaryResponse(
            summary=summary,
            original_length=len(
                request.text.split()
            ),
            summary_length=len(
                summary.split()
            ),
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        )

    except GeminiClientError as exc:

        raise HTTPException(
            status_code=503,
            detail=str(exc),
        )

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "An unexpected error occurred "
                f"while summarizing the text: {exc}"
            ),
        )


# =========================================================
# Learning path endpoint
# =========================================================

@app.post(
    "/learn/recommendations",
    response_model=LearningPathResponse,
)
async def learning_recommendations(
    request: LearningPathRequest,
):

    try:

        result = generate_learning_path(
            topic=request.topic,
            level=request.level,
        )

        return LearningPathResponse(
            topic=result["topic"],
            level=result["level"],
            learning_path=result["learning_path"],
            resources=result["resources"],
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        )

    except GeminiClientError as exc:

        raise HTTPException(
            status_code=503,
            detail=str(exc),
        )

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "An unexpected error occurred "
                "while generating the learning path: "
                f"{exc}"
            ),
        )


# =========================================================
# Application information
# =========================================================

@app.get(
    "/api/info"
)
async def application_info():

    return {
        "application": APP_NAME,
        "version": APP_VERSION,
        "modules": [
            "Question & Answer",
            "Concept Explanation",
            "Quiz Generation",
            "Text Summarization",
            "Learning Path",
        ],
        "endpoints": {
            "qa": "POST /qa",
            "explanation": "POST /explain",
            "quiz": "POST /quiz",
            "summary": "POST /summarize",
            "learning_path": "POST /learn/recommendations",
            "health": "GET /health",
        },
    }


# =========================================================
# Local development entry point
# =========================================================

if __name__ == "__main__":

    import uvicorn

    uvicorn.run(
        "main:app",
        host=HOST,
        port=PORT,
        reload=DEBUG,
    )