"""
EduGenie - Concept Explanation Module

This module explains academic concepts in simple language.

The project documentation specifies LaMini-Flan-T5 for the
concept explanation functionality.
"""

from __future__ import annotations

from typing import Optional

from transformers import pipeline

from config import EXPLANATION_MODEL


# ---------------------------------------------------------
# Model state
# ---------------------------------------------------------

_explanation_pipeline = None
_model_error: Optional[str] = None


# ---------------------------------------------------------
# Load explanation model
# ---------------------------------------------------------

def get_explanation_pipeline():
    """
    Load the LaMini-Flan-T5 model only when it is first needed.

    Lazy loading prevents the application from downloading and
    loading the model during every server startup.
    """

    global _explanation_pipeline
    global _model_error

    if _explanation_pipeline is not None:
        return _explanation_pipeline

    if _model_error is not None:
        raise RuntimeError(_model_error)

    try:

        _explanation_pipeline = pipeline(
            task="text2text-generation",
            model=EXPLANATION_MODEL,
            tokenizer=EXPLANATION_MODEL,
        )

        return _explanation_pipeline

    except Exception as exc:

        _model_error = (
            "Unable to load the explanation model. "
            f"Model: {EXPLANATION_MODEL}. "
            f"Error: {exc}"
        )

        raise RuntimeError(_model_error) from exc


# ---------------------------------------------------------
# Build explanation prompt
# ---------------------------------------------------------

def build_explanation_prompt(
    topic: str,
    level: str = "beginner",
) -> str:
    """
    Build a student-friendly explanation prompt.
    """

    cleaned_topic = topic.strip()
    cleaned_level = level.strip().lower()

    return f"""
Explain the following academic topic to a {cleaned_level} learner.

Topic:
{cleaned_topic}

Requirements:

- Start with a simple definition.
- Explain the main idea clearly.
- Break difficult concepts into smaller points.
- Use simple language.
- Give one practical or everyday example.
- Mention important points the learner should remember.
- Avoid unnecessary technical jargon.
- Keep the explanation educational and easy to revise.

Topic: {cleaned_topic}

Level: {cleaned_level}

Explanation:
""".strip()


# ---------------------------------------------------------
# Generate explanation
# ---------------------------------------------------------

def explain_concept(
    topic: str,
    level: str = "beginner",
) -> str:
    """
    Generate a simple explanation for an academic concept.
    """

    if not topic or not topic.strip():
        raise ValueError(
            "Topic cannot be empty."
        )

    if not level or not level.strip():
        level = "beginner"

    prompt = build_explanation_prompt(
        topic=topic,
        level=level,
    )

    generator = get_explanation_pipeline()

    try:

        result = generator(
            prompt,
            max_new_tokens=350,
            do_sample=True,
            temperature=0.7,
        )

    except Exception as exc:

        raise RuntimeError(
            f"Explanation generation failed: {exc}"
        ) from exc

    if not result:
        raise RuntimeError(
            "Explanation model returned an empty result."
        )

    generated_text = result[0].get(
        "generated_text",
        "",
    )

    if not generated_text.strip():
        raise RuntimeError(
            "Explanation model returned empty text."
        )

    return generated_text.strip()


# ---------------------------------------------------------
# Safe API helper
# ---------------------------------------------------------

def explain_concept_safe(
    topic: str,
    level: str = "beginner",
) -> dict:
    """
    Safe wrapper used by the FastAPI layer.

    Returns a predictable dictionary even when an error occurs.
    """

    try:

        explanation = explain_concept(
            topic=topic,
            level=level,
        )

        return {
            "success": True,
            "topic": topic.strip(),
            "level": level.strip(),
            "explanation": explanation,
            "error": None,
        }

    except ValueError as exc:

        return {
            "success": False,
            "topic": topic,
            "level": level,
            "explanation": "",
            "error": str(exc),
        }

    except RuntimeError as exc:

        return {
            "success": False,
            "topic": topic,
            "level": level,
            "explanation": "",
            "error": str(exc),
        }

    except Exception as exc:

        return {
            "success": False,
            "topic": topic,
            "level": level,
            "explanation": "",
            "error": f"Unexpected error: {exc}",
        }


# ---------------------------------------------------------
# Model status
# ---------------------------------------------------------

def get_model_status() -> dict:
    """
    Return the current status of the local explanation model.
    """

    return {
        "model": EXPLANATION_MODEL,
        "loaded": _explanation_pipeline is not None,
        "error": _model_error,
    }