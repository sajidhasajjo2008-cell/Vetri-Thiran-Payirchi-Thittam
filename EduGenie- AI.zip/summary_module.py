"""
EduGenie - Text Summarization Module

This module takes educational text and generates a concise,
student-friendly summary using Gemini.
"""

from __future__ import annotations

from ai_client import (
    GeminiClientError,
    generate_ai_response,
)


# =========================================================
# Constants
# =========================================================

DEFAULT_MAX_WORDS = 150
MIN_MAX_WORDS = 30
MAX_MAX_WORDS = 500


# =========================================================
# Prompt builder
# =========================================================

def build_summary_prompt(
    text: str,
    max_words: int = DEFAULT_MAX_WORDS,
) -> str:
    """
    Build the summarization prompt.
    """

    return f"""
You are EduGenie, an AI-powered learning assistant.

Summarize the following educational text for a student.

Text:
----------------
{text}
----------------

Requirements:

1. Keep the main ideas and important facts.
2. Remove unnecessary repetition.
3. Use simple and clear language.
4. Preserve important technical terms.
5. Do not introduce information that is not present in the text.
6. Organize the summary into readable paragraphs or bullet points
   when appropriate.
7. Make the summary concise.
8. Aim for approximately {max_words} words or fewer.
9. Do not mention these instructions.
10. Return only the final summary.

Summary:
""".strip()


# =========================================================
# Generate summary
# =========================================================

def summarize_text(
    text: str,
    max_words: int = DEFAULT_MAX_WORDS,
) -> str:
    """
    Generate a concise summary of the supplied text.
    """

    if not text or not text.strip():
        raise ValueError(
            "Text cannot be empty."
        )

    if (
        max_words < MIN_MAX_WORDS
        or max_words > MAX_MAX_WORDS
    ):
        raise ValueError(
            f"max_words must be between "
            f"{MIN_MAX_WORDS} and "
            f"{MAX_MAX_WORDS}."
        )

    cleaned_text = text.strip()

    prompt = build_summary_prompt(
        text=cleaned_text,
        max_words=max_words,
    )

    try:

        summary = generate_ai_response(
            prompt=prompt,
            temperature=0.3,
            max_output_tokens=1500,
        )

    except GeminiClientError:
        raise

    except Exception as exc:

        raise RuntimeError(
            f"Summary generation failed: {exc}"
        ) from exc

    if not summary or not summary.strip():
        raise RuntimeError(
            "Gemini returned an empty summary."
        )

    return summary.strip()


# =========================================================
# Word count helper
# =========================================================

def count_words(text: str) -> int:
    """
    Count words in a text string.
    """

    if not text:
        return 0

    return len(
        text.split()
    )


# =========================================================
# Safe API helper
# =========================================================

def summarize_text_safe(
    text: str,
    max_words: int = DEFAULT_MAX_WORDS,
) -> dict:
    """
    Safe wrapper used by the FastAPI layer.
    """

    try:

        summary = summarize_text(
            text=text,
            max_words=max_words,
        )

        return {
            "success": True,
            "summary": summary,
            "original_length": count_words(text),
            "summary_length": count_words(summary),
            "error": None,
        }

    except ValueError as exc:

        return {
            "success": False,
            "summary": "",
            "original_length": count_words(text),
            "summary_length": 0,
            "error": str(exc),
        }

    except GeminiClientError as exc:

        return {
            "success": False,
            "summary": "",
            "original_length": count_words(text),
            "summary_length": 0,
            "error": str(exc),
        }

    except RuntimeError as exc:

        return {
            "success": False,
            "summary": "",
            "original_length": count_words(text),
            "summary_length": 0,
            "error": str(exc),
        }

    except Exception as exc:

        return {
            "success": False,
            "summary": "",
            "original_length": count_words(text),
            "summary_length": 0,
            "error": f"Unexpected error: {exc}",
        }