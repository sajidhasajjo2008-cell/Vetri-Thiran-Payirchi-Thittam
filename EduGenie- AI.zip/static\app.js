/*
 * =========================================================
 * EduGenie - Frontend JavaScript
 * =========================================================
 *
 * Connects the frontend UI with the FastAPI backend.
 *
 * API endpoints:
 *   POST /qa
 *   POST /explain
 *   POST /quiz
 *   POST /summarize
 *   POST /learn/recommendations
 *   GET  /health
 * =========================================================
 */


/* =========================================================
   DOM HELPERS
   ========================================================= */

function getElement(id) {
    return document.getElementById(id);
}


function showElement(element) {
    if (element) {
        element.classList.remove("hidden");
    }
}


function hideElement(element) {
    if (element) {
        element.classList.add("hidden");
    }
}


/* =========================================================
   GLOBAL UI ELEMENTS
   ========================================================= */

const loading = getElement("loading");
const errorMessage = getElement("errorMessage");


/* =========================================================
   LOADING
   ========================================================= */

function showLoading() {
    showElement(loading);
}


function hideLoading() {
    hideElement(loading);
}


/* =========================================================
   ERROR HANDLING
   ========================================================= */

function showError(message) {

    if (!errorMessage) {
        alert(message);
        return;
    }

    errorMessage.textContent = message;

    showElement(errorMessage);
}


function clearError() {
    hideElement(errorMessage);

    if (errorMessage) {
        errorMessage.textContent = "";
    }
}


/* =========================================================
   API REQUEST HELPER
   ========================================================= */

async function apiRequest(
    endpoint,
    method = "GET",
    body = null
) {

    clearError();

    const options = {
        method: method,
        headers: {
            "Content-Type": "application/json"
        }
    };

    if (body !== null) {
        options.body = JSON.stringify(body);
    }

    const response = await fetch(
        endpoint,
        options
    );

    let data;

    try {
        data = await response.json();
    } catch (error) {
        throw new Error(
            "The server returned an invalid response."
        );
    }

    if (!response.ok) {

        let message = "Something went wrong.";

        if (data && data.detail) {
            message = data.detail;
        }

        throw new Error(message);
    }

    return data;
}


/* =========================================================
   MODULE NAVIGATION
   ========================================================= */

const moduleButtons =
    document.querySelectorAll(
        ".module-button"
    );

const moduleCards =
    document.querySelectorAll(
        ".module-card"
    );


moduleButtons.forEach(
    function (button) {

        button.addEventListener(
            "click",
            function () {

                const moduleName =
                    button.dataset.module;

                moduleButtons.forEach(
                    function (item) {
                        item.classList.remove(
                            "active"
                        );
                    }
                );

                button.classList.add(
                    "active"
                );

                moduleCards.forEach(
                    function (card) {
                        card.classList.remove(
                            "active-module"
                        );
                    }
                );

                const selectedModule =
                    getElement(
                        `${moduleName}-module`
                    );

                if (selectedModule) {

                    selectedModule.classList.add(
                        "active-module"
                    );
                }

                clearError();
            }
        );

    }
);


/* =========================================================
   BACKEND HEALTH CHECK
   ========================================================= */

async function checkBackendStatus() {

    const statusDot =
        getElement("statusDot");

    const statusText =
        getElement("statusText");

    try {

        const data =
            await apiRequest(
                "/health"
            );

        if (
            data.status === "healthy"
        ) {

            statusDot.classList.add(
                "online"
            );

            statusDot.classList.remove(
                "offline"
            );

            statusText.textContent =
                "Backend online";
        }

    } catch (error) {

        statusDot.classList.add(
            "offline"
        );

        statusDot.classList.remove(
            "online"
        );

        statusText.textContent =
            "Backend offline";
    }
}


/* =========================================================
   Q&A MODULE
   ========================================================= */

const askButton =
    getElement("askButton");


if (askButton) {

    askButton.addEventListener(
        "click",
        async function () {

            const questionInput =
                getElement(
                    "questionInput"
                );

            const result =
                getElement(
                    "qaResult"
                );

            const answer =
                getElement(
                    "qaAnswer"
                );

            const question =
                questionInput.value.trim();

            if (!question) {

                showError(
                    "Please enter a question."
                );

                questionInput.focus();

                return;
            }

            try {

                askButton.disabled = true;

                showLoading();

                const data =
                    await apiRequest(
                        "/qa",
                        "POST",
                        {
                            question: question
                        }
                    );

                answer.textContent =
                    data.answer;

                showElement(result);

            } catch (error) {

                showError(
                    error.message
                );

            } finally {

                askButton.disabled = false;

                hideLoading();
            }
        }
    );
}


/* =========================================================
   EXPLANATION MODULE
   ========================================================= */

const explainButton =
    getElement("explainButton");


if (explainButton) {

    explainButton.addEventListener(
        "click",
        async function () {

            const topicInput =
                getElement(
                    "topicInput"
                );

            const levelInput =
                getElement(
                    "levelInput"
                );

            const result =
                getElement(
                    "explainResult"
                );

            const explanation =
                getElement(
                    "explanationText"
                );

            const topic =
                topicInput.value.trim();

            const level =
                levelInput.value;

            if (!topic) {

                showError(
                    "Please enter a topic."
                );

                topicInput.focus();

                return;
            }

            try {

                explainButton.disabled =
                    true;

                showLoading();

                const data =
                    await apiRequest(
                        "/explain",
                        "POST",
                        {
                            topic: topic,
                            level: level
                        }
                    );

                explanation.textContent =
                    data.explanation;

                showElement(result);

            } catch (error) {

                showError(
                    error.message
                );

            } finally {

                explainButton.disabled =
                    false;

                hideLoading();
            }
        }
    );
}


/* =========================================================
   QUIZ MODULE
   ========================================================= */

const quizButton =
    getElement("quizButton");


if (quizButton) {

    quizButton.addEventListener(
        "click",
        async function () {

            const passageInput =
                getElement(
                    "quizPassage"
                );

            const questionCount =
                getElement(
                    "questionCount"
                );

            const result =
                getElement(
                    "quizResult"
                );

            const questionsContainer =
                getElement(
                    "quizQuestions"
                );

            const passage =
                passageInput.value.trim();

            const count =
                Number(
                    questionCount.value
                );

            if (!passage) {

                showError(
                    "Please paste some learning material."
                );

                passageInput.focus();

                return;
            }

            if (passage.length < 20) {

                showError(
                    "Please provide at least 20 characters of learning material."
                );

                passageInput.focus();

                return;
            }

            try {

                quizButton.disabled =
                    true;

                showLoading();

                const data =
                    await apiRequest(
                        "/quiz",
                        "POST",
                        {
                            passage: passage,
                            number_of_questions: count
                        }
                    );

                renderQuiz(
                    data.questions,
                    questionsContainer
                );

                showElement(result);

            } catch (error) {

                showError(
                    error.message
                );

            } finally {

                quizButton.disabled =
                    false;

                hideLoading();
            }
        }
    );
}


/* =========================================================
   RENDER QUIZ
   ========================================================= */

function renderQuiz(
    questions,
    container
) {

    container.innerHTML = "";

    if (
        !questions ||
        questions.length === 0
    ) {

        container.textContent =
            "No questions were generated.";

        return;
    }

    questions.forEach(
        function (item, index) {

            const questionCard =
                document.createElement(
                    "div"
                );

            questionCard.className =
                "quiz-question";

            const title =
                document.createElement(
                    "h5"
                );

            title.textContent =
                `${index + 1}. ${item.question}`;

            questionCard.appendChild(
                title
            );

            item.options.forEach(
                function (option) {

                    const optionButton =
                        document.createElement(
                            "button"
                        );

                    optionButton.className =
                        "quiz-option";

                    optionButton.type =
                        "button";

                    optionButton.textContent =
                        option;

                    optionButton.addEventListener(
                        "click",
                        function () {

                            const existing =
                                questionCard.querySelector(
                                    ".quiz-answer"
                                );

                            if (existing) {
                                existing.remove();
                            }

                            const feedback =
                                document.createElement(
                                    "div"
                                );

                            feedback.className =
                                "quiz-answer";

                            if (
                                option === item.answer
                            ) {

                                feedback.textContent =
                                    `Correct! ${item.explanation}`;

                            } else {

                                feedback.textContent =
                                    `Correct answer: ${item.answer}. ${item.explanation}`;
                            }

                            questionCard.appendChild(
                                feedback
                            );
                        }
                    );

                    questionCard.appendChild(
                        optionButton
                    );
                }
            );

            container.appendChild(
                questionCard
            );
        }
    );
}


/* =========================================================
   SUMMARY MODULE
   ========================================================= */

const summaryButton =
    getElement("summaryButton");


if (summaryButton) {

    summaryButton.addEventListener(
        "click",
        async function () {

            const textInput =
                getElement(
                    "summaryText"
                );

            const wordsInput =
                getElement(
                    "summaryWords"
                );

            const result =
                getElement(
                    "summaryResult"
                );

            const summaryContent =
                getElement(
                    "summaryContent"
                );

            const summaryStats =
                getElement(
                    "summaryStats"
                );

            const text =
                textInput.value.trim();

            const maxWords =
                Number(
                    wordsInput.value
                );

            if (!text) {

                showError(
                    "Please enter text to summarize."
                );

                textInput.focus();

                return;
            }

            if (text.length < 20) {

                showError(
                    "Please enter at least 20 characters."
                );

                textInput.focus();

                return;
            }

            try {

                summaryButton.disabled =
                    true;

                showLoading();

                const data =
                    await apiRequest(
                        "/summarize",
                        "POST",
                        {
                            text: text,
                            max_words: maxWords
                        }
                    );

                summaryContent.textContent =
                    data.summary;

                summaryStats.innerHTML = "";

                const originalStat =
                    document.createElement(
                        "span"
                    );

                originalStat.className =
                    "stat-item";

                originalStat.textContent =
                    `Original words: ${data.original_length}`;

                const summaryStat =
                    document.createElement(
                        "span"
                    );

                summaryStat.className =
                    "stat-item";

                summaryStat.textContent =
                    `Summary words: ${data.summary_length}`;

                summaryStats.appendChild(
                    originalStat
                );

                summaryStats.appendChild(
                    summaryStat
                );

                showElement(result);

            } catch (error) {

                showError(
                    error.message
                );

            } finally {

                summaryButton.disabled =
                    false;

                hideLoading();
            }
        }
    );
}


/* =========================================================
   LEARNING PATH MODULE
   ========================================================= */

const learningButton =
    getElement(
        "learningButton"
    );


if (learningButton) {

    learningButton.addEventListener(
        "click",
        async function () {

            const topicInput =
                getElement(
                    "learningTopic"
                );

            const levelInput =
                getElement(
                    "learningLevel"
                );

            const result =
                getElement(
                    "learningResult"
                );

            const stepsContainer =
                getElement(
                    "learningSteps"
                );

            const resourcesContainer =
                getElement(
                    "learningResources"
                );

            const topic =
                topicInput.value.trim();

            const level =
                levelInput.value;

            if (!topic) {

                showError(
                    "Please enter a learning topic."
                );

                topicInput.focus();

                return;
            }

            try {

                learningButton.disabled =
                    true;

                showLoading();

                const data =
                    await apiRequest(
                        "/learn/recommendations",
                        "POST",
                        {
                            topic: topic,
                            level: level
                        }
                    );

                renderLearningSteps(
                    data.learning_path,
                    stepsContainer
                );

                renderLearningResources(
                    data.resources,
                    resourcesContainer
                );

                showElement(result);

            } catch (error) {

                showError(
                    error.message
                );

            } finally {

                learningButton.disabled =
                    false;

                hideLoading();
            }
        }
    );
}


/* =========================================================
   RENDER LEARNING STEPS
   ========================================================= */

function renderLearningSteps(
    steps,
    container
) {

    container.innerHTML = "";

    if (
        !steps ||
        steps.length === 0
    ) {

        container.textContent =
            "No learning steps were generated.";

        return;
    }

    steps.forEach(
        function (step) {

            const card =
                document.createElement(
                    "div"
                );

            card.className =
                "learning-step";

            const number =
                document.createElement(
                    "div"
                );

            number.className =
                "step-number";

            number.textContent =
                step.step;

            const content =
                document.createElement(
                    "div"
                );

            const title =
                document.createElement(
                    "h5"
                );

            title.textContent =
                step.topic;

            const description =
                document.createElement(
                    "p"
                );

            description.textContent =
                step.description;

            const meta =
                document.createElement(
                    "div"
                );

            meta.className =
                "step-meta";

            meta.textContent =
                `${step.difficulty} • ${step.estimated_time}`;

            content.appendChild(
                title
            );

            content.appendChild(
                description
            );

            content.appendChild(
                meta
            );

            card.appendChild(
                number
            );

            card.appendChild(
                content
            );

            container.appendChild(
                card
            );
        }
    );
}


/* =========================================================
   RENDER RESOURCES
   ========================================================= */

function renderLearningResources(
    resources,
    container
) {

    container.innerHTML = "";

    if (
        !resources ||
        resources.length === 0
    ) {

        container.textContent =
            "No resources were generated.";

        return;
    }

    resources.forEach(
        function (resource) {

            const card =
                document.createElement(
                    "div"
                );

            card.className =
                "resource-card";

            const title =
                document.createElement(
                    "h5"
                );

            title.textContent =
                resource.title;

            const description =
                document.createElement(
                    "p"
                );

            description.textContent =
                resource.description;

            const type =
                document.createElement(
                    "span"
                );

            type.className =
                "resource-type";

            type.textContent =
                resource.resource_type;

            card.appendChild(
                title
            );

            card.appendChild(
                description
            );

            card.appendChild(
                type
            );

            if (resource.url) {

                const link =
                    document.createElement(
                        "a"
                    );

                link.href =
                    resource.url;

                link.target =
                    "_blank";

                link.rel =
                    "noopener noreferrer";

                link.textContent =
                    "Open Resource";

                link.style.display =
                    "block";

                link.style.marginTop =
                    "10px";

                card.appendChild(
                    link
                );
            }

            container.appendChild(
                card
            );
        }
    );
}


/* =========================================================
   KEYBOARD SHORTCUTS
   ========================================================= */

document.addEventListener(
    "keydown",
    function (event) {

        /*
         * Ctrl + Enter in Q&A textarea
         * submits the question.
         */

        if (
            event.ctrlKey &&
            event.key === "Enter"
        ) {

            const activeModule =
                document.querySelector(
                    ".module-card.active-module"
                );

            if (!activeModule) {
                return;
            }

            if (
                activeModule.id ===
                "qa-module"
            ) {

                if (askButton) {
                    askButton.click();
                }
            }
        }
    }
);


/* =========================================================
   INITIALIZATION
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        checkBackendStatus();

    }
);